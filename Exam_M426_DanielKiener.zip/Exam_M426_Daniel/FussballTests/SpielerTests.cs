﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Fussball.Tests
{
    [TestClass()]
    public class SpielerTests
    {
        [TestMethod()]
        public void TestMethod1()
        {
            var Marktwert = new Spieler("Zigi", 100000, 3, Erfahrung.Hoch);
            Assert.AreEqual(2, Marktwert.MarktWert());
        }
    }
}