﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Fussball.Tests
{
    [TestClass()]
    public class MannschaftTests
    {
        [TestMethod()]
        public void TestMethod1()
        {
            var Kosten = new Mannschaft("List<Fcsg>", "Zigi");
            Assert.AreEqual(3,Kosten.AnzahlKostenProMonat());
        }

    }
    }
}