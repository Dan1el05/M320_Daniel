﻿namespace Fussball
{
    public enum Erfahrung
    {
        Tief = 1,
        Durchschnitt = 2,
        Hoch = 3
    }
}
