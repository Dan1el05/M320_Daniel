﻿namespace Fussball
{
    public class Spieler
    {
        private int fitness; // 1 = tief, 2 = durchschnitt, 3 = hoch
        private int jahresGehalt;

        public Spieler(string name, ZahlenFitnesJahresgehalt zahlenFitnesJahresgehalt, Erfahrung erfahrung)
        {
            strName = name;
            JahresGehalt = jahresGehalt;
            Fitness = fitness;
            Erfahrung = erfahrung;
        }
        public string strName { get; private set; }
        public int JahresGehalt {  get; private set; }
        public int Fitness {
            get => fitness;
            set {
                    if (value == 1)
                    {
                        fitness = (int)FitnessWert.FitnesTief;
                    } else if (value == 2)
                    {
                        fitness = (int)FitnessWert.FitnesDurchschnit;
                    } else
                    {
                        fitness = (int)FitnessWert.FitnesHoch;
                    }
                }
        }
        public Erfahrung Erfahrung { get; set; }
        public int MarktWert()
        {
            if (Fitness > 0 && Erfahrung > 0)
            {
                return 200000 * Fitness * (int)Erfahrung;
  
            }
            return 0;
        }
    }

    public class ZahlenFitnesJahresgehalt
    {
        public int JahresGehalt { get; set; }
        public int Fitness { get; set; }


    }

}
