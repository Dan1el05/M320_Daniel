﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fussball
{
    public enum FitnessWert
    {
        FitnesTief = 1,
        FitnesDurchschnit = 2,
        FitnesHoch = 3
    }
}
