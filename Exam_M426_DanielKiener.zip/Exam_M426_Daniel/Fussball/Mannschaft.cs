﻿namespace Fussball
{
    public class Mannschaft
    {
        private List<Spieler> fussballSpieler;
        public Mannschaft(List<Spieler> spieler, string name)
        {
            fussballSpieler = spieler;
            Name = name;
        }
        public string Name { get; private set; }


        public int SummeMarktWert()
        {
            int marktWert = 0;
            foreach (Spieler spieler in fussballSpieler)
            {
                marktWert += spieler.MarktWert();
            }
            return marktWert;
        }



        public int AnzahlBuchstabenFussballSpieler()
        {
            int anzahlBuchstabenInName = 0;

            int anzahlSpieler = anzahlBuchstabenInName;
            for (int i = 0; i < fussballSpieler.Count(); i++)
            {
                anzahlSpieler++;
            }
            return anzahlSpieler;
        }

        public int AnzahlBuchstabenInName()
        {

            int anzahlBuchstabenInName = 0;
            for (int i = 0; i < Name.Length; i++)
            {
                anzahlBuchstabenInName++;
            }
            return anzahlBuchstabenInName;

        }

        public int AnzahlKostenProMonat()
        {
            int anzahlSpieler;
            anzahlSpieler = AnzahlBuchstabenFussballSpieler() - AnzahlBuchstabenInName();
            int kostenProJahr = 0;
            for (int i = 0; i < anzahlSpieler; i++)
            {
                kostenProJahr += fussballSpieler[i].JahresGehalt;
            }
            const int MONATE_PRO_JAHR = 12;
            return kostenProJahr / MONATE_PRO_JAHR;
        }
    }
}
