﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Exam_320;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Exam_320.Tests
{
    [TestClass()]
    public class ApproverTests
    {
        //Arrange
        President bill = new President();
        VicePresident john = new VicePresident();
        Director max = new Director();

        //Act

        

        //Assert
        


    }
}