﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam_320
{
    public interface ILogger
    {
        public ConsoleLogger(string message);
    }
}
